<?php

$serverName = "localhost";
$username = "root";
$password = "";
$dbName = "mediaDB";

?>