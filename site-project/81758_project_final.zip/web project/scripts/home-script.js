import {createDatabase} from "./utility-functions.js";

window.addEventListener('load', function() {
    createDatabase();
});