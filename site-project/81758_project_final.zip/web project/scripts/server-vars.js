var serverName = "localhost";
var username = "root";
var password = "";
var dbName = "mediaDB";

export {serverName,username,password,dbName};